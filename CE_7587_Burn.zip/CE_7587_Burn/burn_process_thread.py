# 因子线程会阻塞UI主线程,导致UI程序卡死,因止使用QThread线程来执行费时间的逻辑
# 此线程只能关联在Pyqt5内使用,否则不起用
from PyQt5.QtCore import QThread, pyqtSignal

from config_data import Config_Data
from fw_manager import FW_Manager


class MyProcessThread(QThread):
    # 信号类型:str, list
    call_fun_signal = pyqtSignal(str, list)

    def __init__(self, parent=None):
        super(MyProcessThread, self).__init__(parent)

    def run(self):
        try:
            FW_Manager.setQthreadObj(self)
            FW_Manager.startFwBurn(Config_Data.mFwPath, Config_Data.mComNum)
        except Exception as e:
            self.call_fun_signal.emit(FW_Manager.SI_TAG_EXCEPT, [repr(e)])
        finally:
            self.call_fun_signal.emit(FW_Manager.SI_TAG_END, [""])