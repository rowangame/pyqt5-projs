
class Config_Data:
    # 串口类型
    mComNum : str = None

    # 固件文件路径
    mFwPath : str = None

    # 观查者对象
    mObserver = None

    # 测试线程
    mBurnThread = None

    @classmethod
    def clear(cls):
        cls.mComNum = ""
        cls.mFwPath = ""
        cls.mObserver = None
        cls.mBurnThread = None