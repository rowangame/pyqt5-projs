import sys

from PyQt5.QtWidgets import QApplication

from qmain_window import QMaintoolsWindow
from view_main_manager import View_Main_Manager


def showBurnView():
    app = QApplication(sys.argv)
    myMainWindow = QMaintoolsWindow()
    myMainWindow.setObserverObject(View_Main_Manager)

    # 初始化主界面
    View_Main_Manager.getView().setupUi(myMainWindow)
    # 设置主窗口属性
    View_Main_Manager.setMainWindow(myMainWindow)
    # 初始化事件
    View_Main_Manager.initEvents()

    # 禁止窗口最大化
    myMainWindow.setFixedWidth(myMainWindow.width())
    myMainWindow.setFixedHeight(myMainWindow.height())

    # 居中显示
    desktop = QApplication.desktop()
    tmpRect = myMainWindow.geometry()
    tmpX = (desktop.width() - tmpRect.width()) // 2 - 200
    tmpY = (desktop.height() - tmpRect.height()) // 2
    myMainWindow.move(int(tmpX), int(tmpY))

    # 设置标题
    myMainWindow.setWindowTitle("CE_7587_7588-烧入工具-V1.0")

    # # 设置窗口图标(此方法占内存多,但图标显示效果较好,适用于较小的图片)
    # tmpDirName = os.getcwd()
    # ico_path = os.path.join(tmpDirName, 'logo.png')
    # icon = QtGui.QIcon()
    # icon.addPixmap(QtGui.QPixmap(ico_path), QtGui.QIcon.Normal, QtGui.QIcon.Off)
    # myMainWindow.setWindowIcon(icon)

    myMainWindow.show()
    sys.exit(app.exec_())