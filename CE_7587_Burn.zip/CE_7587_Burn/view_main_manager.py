import serial.tools.list_ports

from PyQt5.QtGui import QPalette, QFont
from PyQt5.QtWidgets import QMessageBox, QApplication, QFileDialog, QMainWindow

from burn_process_thread import MyProcessThread
from config_data import Config_Data
from fw_manager import FW_Manager
from view_main import Ui_main_view

class View_Main_Manager(object):
    # ui界面对象
    mView = Ui_main_view()
    mMainWindow: QMainWindow = None

    @classmethod
    def on_com_fresh(cls):
        # print("on_com_fresh")
        wndMain = cls.getView()
        wndMain.comNumSlt.clear()
        wndMain.comNumSlt.addItem("None")

        plist = list(serial.tools.list_ports.comports())
        if len(plist) == 0:
            cls.showWarningInfo("获取串口列表为空")
            return

        for tmpP in plist:
            # print("plist=", tmpP.name)
            wndMain.comNumSlt.addItem(tmpP.name)
        # 默认不选择端口号
        wndMain.comNumSlt.setCurrentIndex(0)
        # 清除串口值
        Config_Data.mComNum = ""

    @classmethod
    def on_file_slt(cls):
        # print("on_file_slt")
        wndMain = cls.getView()
        # 打开文件选择对话框，并只允许选择 .bin 文件
        file_path, _ = QFileDialog.getOpenFileName(cls.mMainWindow, "选择文件", "", "BIN Files (*.bin)")

        # 如果用户选择了文件，显示文件路径
        if file_path:
            Config_Data.mFwPath = file_path
            wndMain.edtFwPath.setText(file_path)
        else:
            Config_Data.mFwPath = ""
            wndMain.edtFwPath.setText("")

    @classmethod
    def solveUiProcess(cls, fname, params):
        try:
            wndMain = cls.getView()
            # print("fname=", fname)
            if fname == FW_Manager.SI_TAG_INFO:
                sText = cls.getInfoStyle(params[0])
                cls.addTextHint(sText)
            elif fname == FW_Manager.SI_TAG_ERROR:
                sText = cls.getErrorStyle(params[0])
                cls.addTextHint(sText)
            elif fname == FW_Manager.SI_TAG_EXCEPT:
                sText = cls.getExceptStyle(params[0])
                cls.addTextHint(sText)
            elif fname == FW_Manager.SI_TAG_PROGRESS:
                wndMain.progressBar.setValue(FW_Manager.burn_progress)
                if (FW_Manager.burn_progress % 5) == 0:
                    sText = cls.getProgressStyle(params[0])
                    cls.addTextHint(sText)
            elif fname == FW_Manager.SI_TAG_SUCCESS:
                sText = cls.getSuccessStyle(params[0])
                cls.addTextHint(sText)
            elif fname == FW_Manager.SI_TAG_END:
                cls.burnEnd()
        except Exception as e:
            sText = cls.getExceptStyle("solveUiProcess.error?" + repr(e))
            cls.addTextHint(sText)

    @classmethod
    def burnEnd(cls):
        wndMain = cls.getView()

        sText = cls.getInfoStyle("烧入结束!")
        cls.addTextHint(sText)

        # 可重新开始烧入
        wndMain.btnBurnStart.setEnabled(True)

        # 执行烧入结束逻辑
        FW_Manager.endBurnProcess()

    @classmethod
    def on_burn_start(cls):
        wndMain = cls.getView()
        # 分析串口类型
        index = wndMain.comNumSlt.currentIndex()
        if index <= 0:
            cls.showWarningInfo("请选择串口类型!")
            return
        # 记录串口类型
        Config_Data.mComNum = wndMain.comNumSlt.itemText(index)

        if len(Config_Data.mFwPath) == 0:
            cls.showWarningInfo("请选择要烧入的文件!")
            return

        # 清空内容
        wndMain.edtMsg.setText("")
        # 防止重复点击
        wndMain.btnBurnStart.setEnabled(False)
        # 进度清零
        wndMain.edtMsg.setText("")

        print("开启烧入线程...")
        Config_Data.mObserver = cls
        Config_Data.mTestThread = MyProcessThread()
        Config_Data.mTestThread.call_fun_signal.connect(cls.solveUiProcess)
        Config_Data.mTestThread.start()

    @classmethod
    def showWarningInfo(cls, info):
        wndMain = cls.mView
        wndMain.mWarning = QMessageBox(QMessageBox.Warning, '警告', info)
        wndMain.mWarning.show()

    @classmethod
    def showInformationInfo(cls, info):
        wndMain = cls.mView
        wndMain.mWarning = QMessageBox(QMessageBox.Information, '提示', info)
        wndMain.mWarning.show()

    # 初始化按钮事件
    @classmethod
    def initEvents(cls):
        # print("init events!")
        Config_Data.clear()

        # 添加按键事件
        wndMain = cls.getView()
        wndMain.btnComFresh.clicked.connect(cls.on_com_fresh)
        wndMain.btnFileSlt.clicked.connect(cls.on_file_slt)
        wndMain.btnBurnStart.clicked.connect(cls.on_burn_start)

        wndMain.edtMsg.setText("")
        wndMain.edtFwPath.setEnabled(True)

        pgb = wndMain.progressBar
        pgb.setMinimum(0)
        pgb.setMaximum(100)
        pgb.setValue(0)
        styleSheet = "QProgressBar { border: 1px solid grey; color: rgb(20,20,20); background-color: #CCCCCC; " \
                     "text-align: center;}QProgressBar::chunk {background-color: rgb(100,200,200); margin: 0.1px;  " \
                     "width: 1px;} "
        pgb.setStyleSheet(styleSheet)
        pgb.setFormat('%p%'.format(pgb.value() - pgb.minimum()))

    @classmethod
    def onWindowCloseEvent(cls, event):
        # print("View_Main_Manager.onWindowCloseEvent...")
        if FW_Manager.burn_state != FW_Manager.BS_FREE:
            info = "固件烧入中，不能退出!"
            cls.showWarningInfo(info)
            event.ignore()
        else:
            event.accept()

    @classmethod
    def getView(cls):
        return View_Main_Manager.mView

    @classmethod
    def setMainWindow(cls, mainWnd: QMainWindow):
        cls.mMainWindow = mainWnd

    @classmethod
    def getInfoStyle(cls, sInfo):
        titleFormat = '<b><font color="#000000" size="4">{}</font></b>'
        return titleFormat.format(sInfo)

    @classmethod
    def getErrorStyle(cls, sInfo):
        titleFormat = '<b><font color="#FF0000" size="4">{}</font></b>'
        return titleFormat.format(sInfo)

    @classmethod
    def getProgressStyle(cls, sInfo):
        titleFormat = '<b><font color="#0000FF" size="4">{}</font></b>'
        return titleFormat.format(sInfo)

    @classmethod
    def getExceptStyle(cls, sInfo):
        titleFormat = '<b><font color="#FF0000" size="4">{}</font></b>'
        return titleFormat.format(sInfo)

    @classmethod
    def getSuccessStyle(cls, sInfo):
        titleFormat = '<b><font color="#00FF00" size="4">{}</font></b>'
        return titleFormat.format(sInfo)

    @classmethod
    def addTextHint(cls, sText):
        wndMain = cls.getView()
        wndMain.edtMsg.append(sText)

        # 滑动到最低端显示
        hVerticalBar = wndMain.edtMsg.verticalScrollBar()
        if hVerticalBar:
            curValue = hVerticalBar.value()
            # minValue = hVerticalBar.minimum()
            maxValue = hVerticalBar.maximum()
            # print(f"cValue={curValue} minValue={minValue}, maxValue={maxValue}")
            if curValue < maxValue:
                hVerticalBar.setValue(maxValue)